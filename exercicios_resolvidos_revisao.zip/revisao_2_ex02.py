# revisao_2_ex02.py
contador = 0
num = 1
while contador < 5:
    if num % 2 == 1:
        print(num)
        contador += 1
    num += 1
