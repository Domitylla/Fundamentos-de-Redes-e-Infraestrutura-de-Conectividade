# revisao_2_ex16.py
n = int(input("Digite um número positivo: "))
soma = sum(range(n + 1))
print("Soma dos", n, "primeiros números naturais:", soma)
