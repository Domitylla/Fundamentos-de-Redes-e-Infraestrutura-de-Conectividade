# revisao_1_ex02.py
n = int(input("Digite um número inteiro: "))
if n > 10:
    print("É maior que 10")
else:
    print("É menor que 10")
