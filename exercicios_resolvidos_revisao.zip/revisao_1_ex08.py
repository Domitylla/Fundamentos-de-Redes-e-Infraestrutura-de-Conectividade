# revisao_1_ex08.py
n = float(input("Digite um número: "))
if n >= 0:
    print("Raiz quadrada:", n ** 0.5)
else:
    print("Número inválido")
