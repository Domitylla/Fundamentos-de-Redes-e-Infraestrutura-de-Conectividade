# revisao_1_ex04.py
a = int(input("Digite o primeiro número: "))
b = int(input("Digite o segundo número: "))
c = int(input("Digite o terceiro número: "))

numeros = sorted([a, b, c])
print("Números em ordem crescente:", numeros)
