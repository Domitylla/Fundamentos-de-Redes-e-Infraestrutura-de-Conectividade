# revisao_2_ex07.py
soma = 0
for _ in range(10):
    n = int(input("Digite um número inteiro: "))
    soma += n
print("Média:", soma / 10)
