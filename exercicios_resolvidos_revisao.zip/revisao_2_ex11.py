# revisao_2_ex11.py
soma = 0
for i in range(0, 100):
    if i % 2 == 0:
        soma += i
print("Soma dos 50 primeiros pares:", soma)
