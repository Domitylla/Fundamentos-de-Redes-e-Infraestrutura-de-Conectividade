# revisao_1_ex11.py
n = int(input("Digite um número: "))
if n % 2 == 0:
    print("Número par")
else:
    print("Número ímpar")
