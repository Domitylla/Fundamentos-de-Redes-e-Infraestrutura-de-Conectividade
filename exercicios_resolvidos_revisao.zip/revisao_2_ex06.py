# revisao_2_ex06.py
soma = 0
for _ in range(10):
    valor = float(input("Digite um valor: "))
    soma += valor
print("Soma:", soma)
