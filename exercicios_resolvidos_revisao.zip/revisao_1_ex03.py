# revisao_1_ex03.py
a = int(input("Digite o primeiro número: "))
b = int(input("Digite o segundo número: "))
print("O maior número é:", a if a > b else b)
