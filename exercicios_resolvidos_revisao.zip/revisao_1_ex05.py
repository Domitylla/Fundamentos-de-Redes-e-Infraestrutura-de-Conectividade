# revisao_1_ex05.py
sexo = input("Digite o sexo (F/M): ").upper()
if sexo == 'F':
    print("Feminino")
elif sexo == 'M':
    print("Masculino")
else:
    print("Sexo Inválido")
