# revisao_1_ex10.py
n = float(input("Digite um número: "))
if n > 0:
    print("Quadrado:", n ** 2)
    print("Raiz quadrada:", n ** 0.5)
