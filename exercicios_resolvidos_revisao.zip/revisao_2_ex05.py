# revisao_2_ex05.py
n = 0
while n <= 100000:
    print(n)
    n += 1000
