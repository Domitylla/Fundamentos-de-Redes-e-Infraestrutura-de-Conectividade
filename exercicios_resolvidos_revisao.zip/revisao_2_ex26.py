# revisao_2_ex26.py
s = 0
for i in range(1, 51):
    numerador = 2 * i - 1
    s += numerador / i
print("Valor de S:", s)
