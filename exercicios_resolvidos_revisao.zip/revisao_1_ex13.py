# revisao_1_ex13.py
a = int(input("Digite o primeiro número: "))
b = int(input("Digite o segundo número: "))
c = int(input("Digite o terceiro número: "))

if a < b < c:
    print("Crescente")
else:
    print("Não está em ordem crescente")
