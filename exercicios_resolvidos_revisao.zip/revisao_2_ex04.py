# revisao_2_ex04.py
print("Usando for:")
for i in range(1, 101):
    print(i)

print("\nUsando while:")
i = 1
while i <= 100:
    print(i)
    i += 1
