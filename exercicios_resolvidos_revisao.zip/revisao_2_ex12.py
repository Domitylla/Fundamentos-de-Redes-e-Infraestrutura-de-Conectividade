# revisao_2_ex12.py
n = int(input("Digite um número inteiro positivo: "))
for i in range(n + 1):
    print(i)
