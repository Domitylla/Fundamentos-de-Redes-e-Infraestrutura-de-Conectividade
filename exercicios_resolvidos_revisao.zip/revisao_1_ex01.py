# revisao_1_ex01.py
# Lê 2 inteiros e 1 real, e faz três operações
a = int(input("Digite o primeiro número inteiro: "))
b = int(input("Digite o segundo número inteiro: "))
c = float(input("Digite o número real: "))

print("Produto do primeiro com metade do segundo:", a * (b / 2))
print("Soma do triplo do primeiro com o terceiro:", (3 * a) + c)
print("Terceiro número ao cubo:", c ** 3)
