# revisao_2_ex03.py
contador = 0
num = 1
while contador < 10:
    if num % 2 == 0:
        print(num)
        contador += 1
    num += 1
