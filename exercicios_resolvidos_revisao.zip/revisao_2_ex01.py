# revisao_2_ex01.py
i = 10
while i >= 0:
    print(i)
    i -= 1
print("FIM!")
