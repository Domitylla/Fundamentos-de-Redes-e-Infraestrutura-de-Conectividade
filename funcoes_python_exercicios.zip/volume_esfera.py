import math
def volume_esfera(raio):
    return (4/3) * math.pi * (raio ** 3)