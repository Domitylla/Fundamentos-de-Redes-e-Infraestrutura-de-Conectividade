def potencia_manual(x, z):
    resultado = 1
    for _ in range(z):
        resultado *= x
    return resultado