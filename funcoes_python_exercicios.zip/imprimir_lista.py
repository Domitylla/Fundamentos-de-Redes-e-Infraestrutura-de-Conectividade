def imprimir_lista(lista):
    for i, item in enumerate(lista, 1):
        print(f"{i}, {item}")