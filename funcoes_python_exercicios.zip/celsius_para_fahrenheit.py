def celsius_para_fahrenheit(c):
    return c * 9.0 / 5.0 + 32.0