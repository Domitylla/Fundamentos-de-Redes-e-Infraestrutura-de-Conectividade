def converte_para_segundos(h, m, s):
    return h * 3600 + m * 60 + s