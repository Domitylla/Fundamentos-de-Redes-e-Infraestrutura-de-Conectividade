def maior_de_tres(a, b, c):
    return max(a, b, c)