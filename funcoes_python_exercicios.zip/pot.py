def pot(base, n):
    for i in range(1, n + 1):
        print(f"{base} ** {i} = {base ** i}")