def media_lista(lista):
    return sum(lista) / len(lista) if lista else 0