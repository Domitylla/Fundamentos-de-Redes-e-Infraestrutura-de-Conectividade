def verifica_numero(n):
    return 1 if n > 0 else -1 if n < 0 else 0