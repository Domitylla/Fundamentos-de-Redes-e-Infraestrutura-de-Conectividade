import math
def volume_cilindro(altura, raio):
    return math.pi * (raio ** 2) * altura