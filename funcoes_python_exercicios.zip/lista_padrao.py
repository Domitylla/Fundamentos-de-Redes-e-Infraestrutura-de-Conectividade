def lista_padrao(qtd, valor):
    return [valor] * qtd